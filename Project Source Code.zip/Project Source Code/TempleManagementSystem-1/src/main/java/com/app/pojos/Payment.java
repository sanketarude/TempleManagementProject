package com.app.pojos;

import java.time.LocalDate;

public class Payment {

	
	private Integer pId;
	private double pAmount;
	private LocalDate pDate;
	
	
	
}
